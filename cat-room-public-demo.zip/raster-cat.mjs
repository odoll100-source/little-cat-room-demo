import {createActor,command,target,advance,limit} from './actor-state.mjs';
// Source rectangles were measured per pose, not assumed to be an equal sprite grid.
// Each entry has its own floor anchor. All rendering shares one world scale.
export const POSES={
 'walk-a':['walk',0,0,790,510,390,486], 'walk-b':['walk',795,0,741,510,370,486],
 'walk-c':['walk',0,515,790,509,390,443], 'walk-d':['walk',795,515,741,509,370,443],
 stand:['posture',0,0,835,515,418,490],sit:['rest',60,0,650,540,325,524],
 lie:['posture',0,565,798,459,399,382],rise:['posture',805,520,731,504,366,440],
 crouch:['jump',0,0,790,515,395,475],push:['jump',795,0,741,518,370,512],
 air:['jump',0,519,790,505,395,350],land:['jump',795,530,741,494,370,437],
 blink:['rest',805,0,650,540,325,524],pet:['rest',60,540,650,484,325,460],sleep:['rest',730,700,806,324,403,270]
};
const sources={walk:'01-walk-cycle.png',posture:'02-posture-keys.png',jump:'03-jump-keys.png',rest:'04-rest-expressions.png'};
async function load(src){const image=new Image();image.src='/assets/'+src;await image.decode();return image;}
export async function mountRasterCat(button,room){
 const images=Object.fromEntries(await Promise.all(Object.entries(sources).map(async([k,v])=>[k,await load(v)])));
 button.replaceChildren();const canvas=document.createElement('canvas');canvas.width=900;canvas.height=700;canvas.setAttribute('aria-hidden','true');button.append(canvas);const ctx=canvas.getContext('2d');
 const wrap=button.parentElement,s=createActor(),media=matchMedia('(prefers-reduced-motion: reduce)');let reducedOverride=false,last=0,raf=0,visible=true,dead=false,gaze=0,coat='ginger',fur='fluffy';
 function render(dt=0){const reduced=media.matches||reducedOverride,p=advance(s,dt,{reduced});const [key,sx,sy,sw,sh,ax,ay]=POSES[p.pose];ctx.clearRect(0,0,900,700);ctx.save();
  ctx.fillStyle=`rgba(83,53,28,${p.shadowAlpha})`;ctx.filter='blur(9px)';ctx.beginPath();ctx.ellipse(450,653,225*p.shadowScale,20*p.shadowScale,0,0,Math.PI*2);ctx.fill();ctx.filter='none';
  ctx.translate(450,650-p.lift);const facing=p.mode==='walk'&&s.tx>s.x?-1:1;ctx.scale(facing*(fur==='short'?.98:1),p.breath); // Walk faces its destination; body profile remains a preview.
  ctx.filter=coat==='silver'?'saturate(0.08) brightness(1.04)':coat==='tuxedo'?'saturate(0.05) brightness(.65) contrast(1.4)':'none';
  ctx.drawImage(images[key],sx,sy,sw,sh,-ax,-ay,sw,sh);
  // Only the neutral seated eye layer follows the pointer. Whole-body rotation is avoided to keep paws grounded.
  if(p.pose==='sit'&&!reduced){ctx.filter='none';for(const [ex,ey] of [[163,130],[225,157]]){ctx.save();ctx.beginPath();ctx.ellipse(ex-ax,ey-ay,10,12,.15,0,Math.PI*2);ctx.clip();const iris=ctx.createRadialGradient(ex-ax,ey-ay,2,ex-ax,ey-ay,13);iris.addColorStop(0,'#b0a66d');iris.addColorStop(1,'#68633f');ctx.fillStyle=iris;ctx.fillRect(ex-ax-14,ey-ay-14,28,28);ctx.fillStyle='#302c20';ctx.beginPath();ctx.ellipse(ex-ax+gaze*2.4,ey-ay,5,9,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#fff7e7';ctx.beginPath();ctx.arc(ex-ax-2+gaze*2.4,ey-ay-5,2.3,0,Math.PI*2);ctx.fill();ctx.restore();}}
  ctx.restore();
  wrap.style.left=p.x+'%';wrap.style.top=p.y+'%';const treat=room.querySelector('#treat');treat.style.left=(p.x+2)+'%';treat.style.top=(p.y+40)+'%';button.dataset.motion=p.mode;button.dataset.pose=p.pose;button.dataset.phase=p.phase;button.dataset.paused=String(s.paused);button.dataset.reduced=String(reduced);button.dataset.floor=(650-p.lift).toFixed(1);button.dataset.timeline=s.time.toFixed(3);
 }
 function tick(now){raf=0;if(dead||document.hidden||!visible||s.paused||media.matches||reducedOverride)return;if(!last||now-last>=1000/30-1){render(last?(now-last)/1000:0);last=now;}raf=requestAnimationFrame(tick);}
 function restart(){cancelAnimationFrame(raf);raf=0;last=0;render(0);if(!dead&&!document.hidden&&visible&&!s.paused&&!media.matches&&!reducedOverride)raf=requestAnimationFrame(tick);}
 const mutation=new MutationObserver(()=>{command(s,button.className.split(' ').find(c=>c!=='cat')||'sit');restart();});mutation.observe(button,{attributes:true,attributeFilter:['class']});
 const pointer=e=>{const r=button.getBoundingClientRect();gaze=limit((e.clientX-r.left-r.width/2)/r.width,-1,1);};const leave=()=>{gaze=0;};room.addEventListener('pointermove',pointer);room.addEventListener('pointerleave',leave);
 const visibility=()=>restart();document.addEventListener('visibilitychange',visibility);media.addEventListener('change',restart);const observer=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;restart();});observer.observe(room);restart();
 return {moveTo(x,y){target(s,x,y);if(media.matches||reducedOverride){s.x=s.tx;s.y=s.ty;render();}},setAppearance(c,f){coat=c;fur=f;render();},setPaused(value){s.paused=value;restart();},setReduced(value){reducedOverride=value;restart();},destroy(){dead=true;cancelAnimationFrame(raf);observer.disconnect();mutation.disconnect();document.removeEventListener('visibilitychange',visibility);media.removeEventListener('change',restart);room.removeEventListener('pointermove',pointer);room.removeEventListener('pointerleave',leave);}};
}
