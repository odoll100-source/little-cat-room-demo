export const limit=(n,a,b)=>Math.max(a,Math.min(b,Number.isFinite(n)?n:a));
export const MODES=new Set(['idle','sit','stand','walk','lie','sleep','jump','wand','pet','brush','treat']);
export function createActor(){return {mode:'sit',time:0,clock:0,x:42,y:40,tx:42,ty:40,paused:false,previous:'sit'};}
export function command(s,mode){if(mode==='treat'&&s.mode==='treat')return;s.startLift=s.lastLift||0;s.previous=s.mode;s.mode=MODES.has(mode)?mode:'sit';s.time=0;if(mode==='treat'){s.tx=s.x;s.ty=s.y;}}
export function target(s,x,y){s.tx=limit(x,2,55);s.ty=limit(y,32,47);}
export function advance(s,dt,{reduced=false}={}){
 dt=limit(dt,0,.1);if(!s.paused){s.time+=dt;s.clock+=dt;const speed=reduced?1:Math.min(1,dt*2.2);s.x+=(s.tx-s.x)*speed;s.y+=(s.ty-s.y)*speed;}
 let pose='sit',lift=0,phase=s.mode;const t=s.time;
 if(s.mode==='walk'){pose=reduced?'stand':['walk-a','walk-b','walk-c','walk-d'][Math.floor(t*5)%4];if(t>2.8){s.mode='stand';pose='stand';}}
 else if(['jump','wand'].includes(s.mode)){
  if(reduced){pose='stand';if(t>1.5)s.mode='stand';}
  else if(t<.3){pose='crouch';phase='prepare';}
  else if(t<.47){pose='push';lift=(t-.3)/.17*55;phase='takeoff';}
  else if(t<1.07){pose='air';const u=(t-.47)/.6;lift=55*(1-u)+125*Math.sin(u*Math.PI);phase='airborne';}
  else if(t<1.35){pose='land';phase='landing';}
  else {s.mode='stand';pose='stand';phase='stand';}
 }
 else if(s.mode==='stand')pose=t<.25&&!reduced&&['lie','sleep'].includes(s.previous)?'rise':'stand';
 else if(s.mode==='lie'||s.mode==='sleep'){pose=t<.3&&!reduced?'rise':s.mode==='sleep'?'sleep':'lie';}
 else if(s.mode==='treat'){pose='crouch';if(!reduced&&s.startLift>0&&t<.25){lift=s.startLift*(1-t/.25);pose='air';phase='settling';}}
 else if(s.mode==='pet'||s.mode==='brush')pose='pet';
 else {pose=t<.25&&!reduced&&['lie','sleep'].includes(s.previous)?'rise':'sit';if(!reduced&&s.clock%5.4>5.18)pose='blink';}
 s.lastLift=lift;
 return {pose,lift,phase,mode:s.mode,x:s.x,y:s.y,breath:reduced||s.paused?1:1+Math.sin(s.clock*1.7)*.006,shadowScale:1-lift/500,shadowAlpha:.2-lift/1200};
}
